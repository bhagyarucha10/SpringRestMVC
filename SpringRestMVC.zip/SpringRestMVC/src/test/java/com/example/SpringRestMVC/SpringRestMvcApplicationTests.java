package com.example.SpringRestMVC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestMvcApplicationTests {

	@Test
	void contextLoads() {
	}

}
